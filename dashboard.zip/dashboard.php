
<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . "/config/db.php";

$userId = $_SESSION["user_id"];


// ---------------- TOTAL SUMMARY ----------------
$sql = "SELECT
            COUNT(*) AS total_bills,
            COALESCE(SUM(units_kwh), 0) AS total_units,
            COALESCE(SUM(amount), 0) AS total_amount
        FROM bills
        WHERE user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();

$summary = $stmt->get_result()->fetch_assoc();
$stmt->close();

$totalBills = (int)$summary["total_bills"];
$totalUnits = (float)$summary["total_units"];
$totalAmount = (float)$summary["total_amount"];


// ---------------- RECENT BILLS ----------------
$sql = "SELECT *
        FROM bills
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();
$recentBills = [];

while ($row = $result->fetch_assoc()) {
    $recentBills[] = $row;
}

$stmt->close();


// ---------------- MONTHLY CONSUMPTION ----------------
$sql = "SELECT
            DATE_FORMAT(bill_date, '%b %Y') AS month_label,
            SUM(units_kwh) AS monthly_units,
            YEAR(bill_date) AS year_num,
            MONTH(bill_date) AS month_num
        FROM bills
        WHERE user_id = ?
          AND bill_date IS NOT NULL
        GROUP BY year_num, month_num, month_label
        ORDER BY year_num DESC, month_num DESC
        LIMIT 6";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();
$monthlyData = [];

while ($row = $result->fetch_assoc()) {
    $monthlyData[] = $row;
}

$stmt->close();

// Reverse to show oldest month first
$monthlyData = array_reverse($monthlyData);

$maxUnits = 0;

foreach ($monthlyData as $month) {
    if ((float)$month["monthly_units"] > $maxUnits) {
        $maxUnits = (float)$month["monthly_units"];
    }
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

function formatDate($date) {
    if (!$date) {
        return "N/A";
    }

    return date("d-m-Y", strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>WattWise Dashboard</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #f1f5f9;
    color: #1e293b;
}

.navbar {
    background: #166534;
    color: white;
    padding: 18px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.navbar h2 {
    margin: 0;
}

.nav-links {
    display: flex;
    gap: 18px;
    flex-wrap: wrap;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

.container {
    max-width: 1150px;
    margin: 30px auto;
    padding: 0 20px;
}

.welcome {
    margin-bottom: 25px;
}

.welcome h1 {
    margin-bottom: 8px;
}

.welcome p {
    color: #64748b;
}

.cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 3px 15px #00000008;
}

.card p {
    color: #64748b;
    margin-top: 0;
}

.card h2 {
    color: #166534;
    margin-bottom: 0;
    font-size: 28px;
}

.section {
    background: white;
    padding: 25px;
    border-radius: 15px;
    margin-top: 25px;
    box-shadow: 0 3px 15px #00000008;
}

.section h2 {
    margin-top: 0;
}

.chart {
    display: flex;
    align-items: flex-end;
    justify-content: space-around;
    gap: 12px;
    height: 260px;
    padding: 20px 5px 0;
    border-bottom: 1px solid #cbd5e1;
}

.bar-item {
    flex: 1;
    text-align: center;
    min-width: 0;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;
}

.bar {
    width: 65%;
    max-width: 65px;
    min-height: 5px;
    background: #22c55e;
    border-radius: 8px 8px 0 0;
}

.bar-value {
    font-size: 12px;
    margin-bottom: 6px;
    color: #166534;
    font-weight: bold;
}

.bar-label {
    font-size: 12px;
    color: #64748b;
    margin-top: 8px;
    min-height: 32px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

.table-wrapper {
    overflow-x: auto;
}

th, td {
    padding: 13px;
    border-bottom: 1px solid #e2e8f0;
    text-align: center;
    white-space: nowrap;
}

th {
    color: #166534;
    background: #f0fdf4;
}

.view-link {
    color: #2563eb;
    text-decoration: none;
    font-weight: bold;
}

.actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 25px;
}

.btn {
    display: inline-block;
    padding: 13px 20px;
    border-radius: 9px;
    text-decoration: none;
    background: #16a34a;
    color: white;
    font-weight: bold;
}

.btn:hover {
    background: #15803d;
}

.empty {
    text-align: center;
    color: #64748b;
    padding: 25px;
}

@media(max-width: 750px) {

    .cards {
        grid-template-columns: 1fr;
    }

    .navbar {
        padding: 18px;
    }

    .container {
        padding: 0 12px;
    }

    .section {
        padding: 15px;
    }

}

</style>

</head>

<body>


<!-- NAVIGATION -->

<div class="navbar">

    <h2>⚡ WattWise</h2>

    <div class="nav-links">

        <a href="dashboard.php">Dashboard</a>

        <a href="bills/upload_bill.php">Upload Bill</a>

        <a href="bills/my_bills.php">My Bills</a>

        <a href="logout.php">Logout</a>
<a href="analytics.php" class="btn">
    📊 Electricity Analytics
</a>
    </div>

</div>


<div class="container">


<!-- WELCOME -->

<div class="welcome">

    <h1>Welcome to WattWise 👋</h1>

    <p>
        Monitor your electricity consumption and bills.
    </p>

</div>


<!-- SUMMARY CARDS -->

<div class="cards">

    <div class="card">

        <p>📄 Total Bills Uploaded</p>

        <h2><?= $totalBills ?></h2>

    </div>


    <div class="card">

        <p>⚡ Total Electricity Consumed</p>

        <h2><?= number_format($totalUnits, 2) ?> kWh</h2>

    </div>


    <div class="card">

        <p>💰 Total Bill Amount</p>

        <h2>₹<?= number_format($totalAmount, 2) ?></h2>

    </div>

</div>


<!-- MONTHLY CHART -->

<div class="section">

    <h2>📊 Monthly Electricity Consumption</h2>

    <?php if (!empty($monthlyData) && $maxUnits > 0): ?>

        <div class="chart">

            <?php foreach ($monthlyData as $month): ?>

                <?php
                    $units = (float)$month["monthly_units"];

                    $height = ($units / $maxUnits) * 180;
                ?>

                <div class="bar-item">

                    <div class="bar-value">
                        <?= number_format($units, 0) ?>
                    </div>

                    <div
                        class="bar"
                        style="height: <?= $height ?>px;"
                        title="<?= h($month["month_label"]) ?>: <?= $units ?> kWh"
                    ></div>

                    <div class="bar-label">
                        <?= h($month["month_label"]) ?>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <p style="text-align:center;color:#64748b;">
            Electricity usage in kWh
        </p>

    <?php else: ?>

        <div class="empty">
            No consumption data available yet.
        </div>

    <?php endif; ?>

</div>


<!-- RECENT BILLS -->

<div class="section">

    <h2>🧾 Recent Bills</h2>

    <?php if (!empty($recentBills)): ?>

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>
                        <th>Bill Date</th>
                        <th>Units</th>
                        <th>Amount</th>
                        <th>Due Date</th>
                        <th>Bill</th>
                    </tr>

                </thead>

                <tbody>

                <?php foreach ($recentBills as $bill): ?>

                    <tr>

                        <td>
                            <?= h(formatDate($bill["bill_date"])) ?>
                        </td>

                        <td>
                            <?= h($bill["units_kwh"]) ?> kWh
                        </td>

                        <td>
                            ₹<?= number_format(
                                (float)$bill["amount"],
                                2
                            ) ?>
                        </td>

                        <td>
                            <?= h(formatDate($bill["due_date"])) ?>
                        </td>

                        <td>

                            <?php if (!empty($bill["image_path"])): ?>

                                <a
                                    class="view-link"
                                    href="<?= h($bill["image_path"]) ?>"
                                    target="_blank"
                                >
                                    View Bill
                                </a>

                            <?php else: ?>

                                N/A

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php else: ?>

        <div class="empty">
            No bills uploaded yet. Upload your first electricity bill!
        </div>

    <?php endif; ?>


    <div class="actions">

        <a class="btn" href="bills/upload_bill.php">
            + Upload New Bill
        </a>

        <a class="btn" href="bills/my_bills.php">
            View All Bills
        </a>

    </div>

</div>


</div>

</body>

</html>
