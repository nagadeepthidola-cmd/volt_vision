
<?php
session_start();

require_once __DIR__ . "/config/db.php";

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$prediction = null;
$error = "";

$values = [
    "fan" => 0,
    "refrigerator" => 0,
    "air_conditioner" => 0,
    "television" => 0,
    "monitor" => 0,
    "motor_pump" => 0,
    "month" => date("n"),
    "city" => "",
    "company" => "",
    "monthly_hours" => 300,
    "tariff_rate" => 8.4
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($values as $key => $default) {
        if (isset($_POST[$key])) {
            $values[$key] = trim($_POST[$key]);
        }
    }

    // Validate input
    $applianceFields = [
        "fan",
        "refrigerator",
        "air_conditioner",
        "television",
        "monitor",
        "motor_pump"
    ];

    foreach ($applianceFields as $field) {
        if (!is_numeric($values[$field]) || (int)$values[$field] < 0) {
            $error = "Appliance counts must be valid non-negative numbers.";
            break;
        }
    }

    if (!$error && (
        !is_numeric($values["month"]) ||
        (int)$values["month"] < 1 ||
        (int)$values["month"] > 12
    )) {
        $error = "Please select a valid month.";
    }

    if (!$error && (
        !is_numeric($values["monthly_hours"]) ||
        (float)$values["monthly_hours"] <= 0
    )) {
        $error = "Monthly usage hours must be greater than zero.";
    }

    if (!$error && (
        !is_numeric($values["tariff_rate"]) ||
        (float)$values["tariff_rate"] <= 0
    )) {
        $error = "Tariff rate must be greater than zero.";
    }

    if (!$error && (
        empty($values["city"]) ||
        empty($values["company"])
    )) {
        $error = "Please enter your city and electricity company.";
    }

    if (!$error) {

        // Convert form data into model input
        $inputData = [
            "Fan" => (int)$values["fan"],
            "Refrigerator" => (int)$values["refrigerator"],
            "AirConditioner" => (int)$values["air_conditioner"],
            "Television" => (int)$values["television"],
            "Monitor" => (int)$values["monitor"],
            "MotorPump" => (int)$values["motor_pump"],
            "Month" => (int)$values["month"],
            "City" => $values["city"],
            "Company" => $values["company"],
            "MonthlyHours" => (float)$values["monthly_hours"],
            "TariffRate" => (float)$values["tariff_rate"]
        ];

        $mlDirectory = __DIR__ . "/ml";
        $pythonFile = $mlDirectory . "/predict.py";

        // Create a unique temporary JSON file
        $inputFile = $mlDirectory . "/input_" . uniqid() . ".json";

        if (!file_exists($pythonFile)) {
            $error = "Python prediction file not found: ml/predict.py";
        } else {

            $jsonData = json_encode($inputData);

            if (file_put_contents($inputFile, $jsonData) === false) {
                $error = "Unable to create ML input file.";
            } else {

                // Run Python ML model
                $command = "python "
                    . escapeshellarg($pythonFile) . " "
                    . escapeshellarg($inputFile)
                    . " 2>&1";

                $output = [];
                $returnCode = 0;

                exec($command, $output, $returnCode);

                // Delete temporary input file
                if (file_exists($inputFile)) {
                    unlink($inputFile);
                }

                $result = json_decode(
                    implode("\n", $output),
                    true
                );

                if (
                    is_array($result) &&
                    isset($result["success"]) &&
                    $result["success"] === true &&
                    isset($result["predicted_bill"])
                ) {

                    $prediction = (float)$result["predicted_bill"];

                    // Save prediction in database
                    try {

                        $stmt = $conn->prepare(
                            "INSERT INTO predictions
                            (
                                user_id,
                                fan,
                                refrigerator,
                                air_conditioner,
                                television,
                                monitor,
                                motor_pump,
                                month,
                                city,
                                company,
                                monthly_hours,
                                tariff_rate,
                                predicted_bill
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                        );

                        $stmt->bind_param(
                            "iiiiiiiissddd",
                            $user_id,
                            $inputData["Fan"],
                            $inputData["Refrigerator"],
                            $inputData["AirConditioner"],
                            $inputData["Television"],
                            $inputData["Monitor"],
                            $inputData["MotorPump"],
                            $inputData["Month"],
                            $inputData["City"],
                            $inputData["Company"],
                            $inputData["MonthlyHours"],
                            $inputData["TariffRate"],
                            $prediction
                        );

                        $stmt->execute();
                        $stmt->close();

                    } catch (Exception $e) {
                        $error = "Prediction generated, but database saving failed: "
                            . $e->getMessage();
                    }

                } else {
                    $error = "ML prediction failed. ";

                    if (isset($result["error"])) {
                        $error .= $result["error"];
                    } else {
                        $error .= implode("\n", $output);
                    }
                }
            }
        }
    }
}

$months = [
    1 => "January",
    2 => "February",
    3 => "March",
    4 => "April",
    5 => "May",
    6 => "June",
    7 => "July",
    8 => "August",
    9 => "September",
    10 => "October",
    11 => "November",
    12 => "December"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>WattWise - Predict Electricity Bill</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f8f4;
    color: #263238;
}

.container {
    max-width: 850px;
    margin: 35px auto;
    background: white;
    padding: 30px;
    border-radius: 14px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
}

h1 {
    text-align: center;
    color: #16834a;
    margin-bottom: 8px;
}

.subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 30px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 7px;
    font-size: 15px;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #16834a;
}

.full-width {
    grid-column: 1 / -1;
}

.predict-btn {
    width: 100%;
    padding: 15px;
    margin-top: 25px;
    background: #16834a;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 17px;
    font-weight: bold;
    cursor: pointer;
}

.predict-btn:hover {
    background: #106a3a;
}

.result {
    margin-top: 25px;
    padding: 22px;
    text-align: center;
    background: #e8f7ee;
    border: 1px solid #a5d6b7;
    border-radius: 10px;
}

.result h2 {
    color: #16834a;
    margin-bottom: 8px;
}

.amount {
    font-size: 32px;
    font-weight: bold;
    color: #16834a;
}

.error {
    margin-top: 20px;
    padding: 15px;
    background: #ffeaea;
    color: #b00020;
    border-radius: 8px;
    overflow-wrap: anywhere;
}

.links {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 25px;
    flex-wrap: wrap;
}

.links a {
    color: #16834a;
    text-decoration: none;
    font-weight: bold;
}

@media(max-width: 600px) {
    .container {
        margin: 15px;
        padding: 20px;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .full-width {
        grid-column: auto;
    }
}
</style>
</head>

<body>

<div class="container">

    <h1>⚡ WattWise</h1>

    <p class="subtitle">
        Predict My Electricity Bill
        <br>
        Enter your household appliance and electricity details.
    </p>

    <form method="POST">

        <div class="form-grid">

            <div class="form-group">
                <label>Number of Fans</label>
                <input type="number" name="fan" min="0"
                value="<?php echo htmlspecialchars((string)$values['fan']); ?>" required>
            </div>

            <div class="form-group">
                <label>Refrigerators</label>
                <input type="number" name="refrigerator" min="0"
                value="<?php echo htmlspecialchars((string)$values['refrigerator']); ?>" required>
            </div>

            <div class="form-group">
                <label>Air Conditioners</label>
                <input type="number" name="air_conditioner" min="0"
                value="<?php echo htmlspecialchars((string)$values['air_conditioner']); ?>" required>
            </div>

            <div class="form-group">
                <label>Televisions</label>
                <input type="number" name="television" min="0"
                value="<?php echo htmlspecialchars((string)$values['television']); ?>" required>
            </div>

            <div class="form-group">
                <label>Monitors</label>
                <input type="number" name="monitor" min="0"
                value="<?php echo htmlspecialchars((string)$values['monitor']); ?>" required>
            </div>

            <div class="form-group">
                <label>Motor Pumps</label>
                <input type="number" name="motor_pump" min="0"
                value="<?php echo htmlspecialchars((string)$values['motor_pump']); ?>" required>
            </div>

            <div class="form-group">
                <label>Month</label>
                <select name="month" required>
                    <?php foreach ($months as $number => $monthName): ?>
                        <option value="<?php echo $number; ?>"
                        <?php echo ((int)$values['month'] === $number) ? 'selected' : ''; ?>>
                            <?php echo $monthName; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>City</label>
                <input type="text" name="city"
                value="<?php echo htmlspecialchars((string)$values['city']); ?>"
                placeholder="Enter your city" required>
            </div>

            <div class="form-group">
                <label>Electricity Company</label>
                <input type="text" name="company"
                value="<?php echo htmlspecialchars((string)$values['company']); ?>"
                placeholder="Enter electricity company" required>
            </div>

            <div class="form-group">
                <label>Monthly Usage Hours</label>
                <input type="number" name="monthly_hours"
                min="0.01" step="0.01"
                value="<?php echo htmlspecialchars((string)$values['monthly_hours']); ?>" required>
            </div>

            <div class="form-group full-width">
                <label>Tariff Rate (₹ per unit)</label>
                <input type="number" name="tariff_rate"
                min="0.01" step="0.01"
                value="<?php echo htmlspecialchars((string)$values['tariff_rate']); ?>" required>
            </div>

        </div>

        <button type="submit" class="predict-btn">
            Predict Electricity Bill
        </button>

    </form>

    <?php if ($prediction !== null && !$error): ?>

        <div class="result">

            <h2>Estimated Electricity Bill</h2>

            <div class="amount">
                ₹<?php echo number_format($prediction, 2); ?>
            </div>

            <p>
                Prediction generated using the trained
                Random Forest ML model.
            </p>

            <p>
                Your prediction has been saved successfully.
            </p>

        </div>

    <?php endif; ?>

    <?php if ($error): ?>

        <div class="error">
            <strong>Error:</strong>
            <?php echo nl2br(htmlspecialchars($error)); ?>
        </div>

    <?php endif; ?>

    <div class="links">
        <a href="dashboard.php">← Back to Dashboard</a>
        <a href="my_predictions.php">My Predictions →</a>
    </div>

</div>

</body>
</html>
